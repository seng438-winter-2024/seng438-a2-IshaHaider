import org.jfree.data.test.DataUtilitiesTest;
import org.jfree.data.test.RangeTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	DataUtilitiesTest.class,
	RangeTest.class
})

public class AllTests {

}
